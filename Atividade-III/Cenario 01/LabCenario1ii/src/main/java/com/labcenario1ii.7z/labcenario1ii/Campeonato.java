package com.labcenario1ii;
/*
 * @author Cadilhe
 */

public class Campeonato {
    private int id;
    private int ano;
    private String nome;

    public Campeonato() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
}
